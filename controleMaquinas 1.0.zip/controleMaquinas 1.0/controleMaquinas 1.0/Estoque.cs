﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controleMaquinas_1._0
{
    class Estoque
    {

        //Construtor
        public Estoque()
        {
            Maquinas = new List<string>();
        }
        public string Tag { get; set; }
        public string Modelo { get; set; }
        public List<string> Maquinas { get; set; }

    }
}
