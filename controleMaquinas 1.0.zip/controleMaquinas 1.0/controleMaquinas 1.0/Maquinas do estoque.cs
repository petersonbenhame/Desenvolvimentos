﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace controleMaquinas_1._0
{
    public partial class Maquinas_do_estoque : Form
    {
        public Maquinas_do_estoque()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conecxao = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ControleEstoque;Data Source=DESKTOP-HNDR4A5\\SQLEXPRESS");

            SqlCommand Instrucoes =new SqlCommand("insert into tblEstoque(Tag, Modelo) values(@Tag, @Modelo)", conecxao);

            Instrucoes.Parameters.Add("@Tag", SqlDbType.VarChar).Value = tagTextBox.Text;
            Instrucoes.Parameters.Add("@Modelo", SqlDbType.VarChar).Value = modeloTextBox.Text;

            try
            {
                conecxao.Open();
                Instrucoes.ExecuteNonQuery();
                MessageBox.Show("Maquina Adiconada Com Sucesso.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);     
            }
            finally
            {
                conecxao.Close();
            }

        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pesquisarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Pesquisar novaPesquisar = new Pesquisar();
            novaPesquisar.Show();
        }
    }
}
