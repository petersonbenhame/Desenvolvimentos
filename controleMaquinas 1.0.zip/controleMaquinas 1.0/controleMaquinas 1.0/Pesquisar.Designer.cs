﻿namespace controleMaquinas_1._0
{
    partial class Pesquisar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pesquisarButton = new System.Windows.Forms.Button();
            this.PesquisaTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.resultadoDataGridView = new System.Windows.Forms.DataGridView();
            this.controleEstoqueDataSet = new controleMaquinas_1._0.ControleEstoqueDataSet();
            this.tblEstoqueBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblEstoqueTableAdapter = new controleMaquinas_1._0.ControleEstoqueDataSetTableAdapters.tblEstoqueTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tagDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modeloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.resultadoDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.controleEstoqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblEstoqueBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pesquisarButton
            // 
            this.pesquisarButton.Location = new System.Drawing.Point(197, 56);
            this.pesquisarButton.Name = "pesquisarButton";
            this.pesquisarButton.Size = new System.Drawing.Size(75, 23);
            this.pesquisarButton.TabIndex = 0;
            this.pesquisarButton.Text = "Pesquisar";
            this.pesquisarButton.UseVisualStyleBackColor = true;
            this.pesquisarButton.Click += new System.EventHandler(this.pesquisarButton_Click);
            // 
            // PesquisaTextBox
            // 
            this.PesquisaTextBox.Location = new System.Drawing.Point(12, 58);
            this.PesquisaTextBox.Name = "PesquisaTextBox";
            this.PesquisaTextBox.Size = new System.Drawing.Size(179, 20);
            this.PesquisaTextBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Pesquisar Maquinas Em Estoque";
            // 
            // resultadoDataGridView
            // 
            this.resultadoDataGridView.AutoGenerateColumns = false;
            this.resultadoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.resultadoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.tagDataGridViewTextBoxColumn,
            this.modeloDataGridViewTextBoxColumn});
            this.resultadoDataGridView.DataSource = this.tblEstoqueBindingSource;
            this.resultadoDataGridView.Location = new System.Drawing.Point(12, 97);
            this.resultadoDataGridView.Name = "resultadoDataGridView";
            this.resultadoDataGridView.Size = new System.Drawing.Size(328, 150);
            this.resultadoDataGridView.TabIndex = 3;
            // 
            // controleEstoqueDataSet
            // 
            this.controleEstoqueDataSet.DataSetName = "ControleEstoqueDataSet";
            this.controleEstoqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblEstoqueBindingSource
            // 
            this.tblEstoqueBindingSource.DataMember = "tblEstoque";
            this.tblEstoqueBindingSource.DataSource = this.controleEstoqueDataSet;
            // 
            // tblEstoqueTableAdapter
            // 
            this.tblEstoqueTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tagDataGridViewTextBoxColumn
            // 
            this.tagDataGridViewTextBoxColumn.DataPropertyName = "Tag";
            this.tagDataGridViewTextBoxColumn.HeaderText = "Tag";
            this.tagDataGridViewTextBoxColumn.Name = "tagDataGridViewTextBoxColumn";
            // 
            // modeloDataGridViewTextBoxColumn
            // 
            this.modeloDataGridViewTextBoxColumn.DataPropertyName = "Modelo";
            this.modeloDataGridViewTextBoxColumn.HeaderText = "Modelo";
            this.modeloDataGridViewTextBoxColumn.Name = "modeloDataGridViewTextBoxColumn";
            // 
            // Pesquisar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 261);
            this.Controls.Add(this.resultadoDataGridView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PesquisaTextBox);
            this.Controls.Add(this.pesquisarButton);
            this.Name = "Pesquisar";
            this.Text = "Pesquisar";
            this.Load += new System.EventHandler(this.Pesquisar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.resultadoDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.controleEstoqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblEstoqueBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button pesquisarButton;
        private System.Windows.Forms.TextBox PesquisaTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView resultadoDataGridView;
        private ControleEstoqueDataSet controleEstoqueDataSet;
        private System.Windows.Forms.BindingSource tblEstoqueBindingSource;
        private ControleEstoqueDataSetTableAdapters.tblEstoqueTableAdapter tblEstoqueTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tagDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modeloDataGridViewTextBoxColumn;
    }
}